public class CircleComparisonExample {
    public static void main(String[] args) {
        // Create two Circle objects
        Circle circle1 = new Circle(5.0);
        Circle circle2 = new Circle(3.0);

        // Compare circles based on their radii
        if (circle1.getRadius() < circle2.getRadius()) {
            System.out.println("Circle 1 is smaller than Circle 2");
        } else if (circle1.getRadius() > circle2.getRadius()) {
            System.out.println("Circle 1 is larger than Circle 2");
        } else {
            System.out.println("Circle 1 is equal to Circle 2");
        }
    }
}
